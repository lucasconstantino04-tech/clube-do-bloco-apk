-- Clube do Bloco: execute somente em um PROJETO SUPABASE NOVO, separado da rifa.
-- Este esquema salva o progresso de cada jogador e restringe leitura/escrita à própria conta.
create table if not exists public.player_saves (
  user_id uuid primary key references auth.users(id) on delete cascade,
  save_data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.player_saves enable row level security;

drop policy if exists "Players can read their own save" on public.player_saves;
create policy "Players can read their own save"
  on public.player_saves for select to authenticated
  using (auth.uid() = user_id);

drop policy if exists "Players can create their own save" on public.player_saves;
create policy "Players can create their own save"
  on public.player_saves for insert to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "Players can update their own save" on public.player_saves;
create policy "Players can update their own save"
  on public.player_saves for update to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- Não coloque a chave service_role no HTML. Use somente a chave publicável/anon.
-- Ranking competitivo validado contra fraude deve ser implementado no servidor antes de abrir a ranqueada online.
